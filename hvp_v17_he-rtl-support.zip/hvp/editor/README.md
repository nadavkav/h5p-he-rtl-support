H5P Editor PHP Library
==========

A general library that is supposed to be used in most PHP implementations of H5P.

## License

All code is licensed under MIT License